<?php
session_start();
include '../funciones/funcionesJuego.php';
include '../funciones/funcionesFicheroUsuario.php';
include '../funciones/funcionesCookies.php';

//Mediante un array  tenemos las categorías del juego
$arrayQuesitos = ["Ciencia","Cultura General","Deportes","Entretenimiento","Geografía","Historia"];
//Comprobamos si se ha iniciado sesion o se juega de forma anonima
if(isset($_SESSION['usuario'])):
    //obtenemos los quesitos guardados
    $quesitos = $_SESSION['quesitos'];
elseif($_COOKIE['user_anonimo']):
    $quesitos = obtener_quesitos_cookie(); 
endif;

//Comprobamos los valores del formulario
if(isset($_POST) && !empty($_POST)){
    if(!isset($_POST['opcion'])||empty($_POST['opcion']) ||
        !isset($_POST['categoria'])||empty($_POST['categoria']) ||
            !isset($_POST['solucion'])||empty($_POST['solucion'])){
        //Si ha habido algun error...
        echo "<script>alert('Error! algo mal ha sucedido... volovemos atras.')</script>";
        header("location:../juego.php");
        die;
        
    }else{
        //Hemos pasado la solucion hasheada para comprobarla con la opcion seleccionada.
        if(password_verify($_POST['opcion'], $_POST['solucion'])){
            $puntuacion =10;
            for ($i = 0;$i<count($arrayQuesitos);$i++):
                //Guardamos el quesito ganado
                if($arrayQuesitos[$i] == $_POST['categoria']){
                    $quesitos[$i]=$arrayQuesitos[$i];
                }
            endfor;
        }else{
            $puntuacion =-4;
        }
    }
    
    //Actualizamos la sesion o la cookie
    if(isset($_SESSION['usuario'])):
        $_SESSION['quesitos'] = $quesitos;
        $_SESSION['puntuacion'] = $_SESSION['puntuacion']+ $puntuacion;
        $_SESSION['num_preguntas'] = 1;
        //Guardamos los datos en los ficheros
        //Actualizamos los valores de los ficheros
        guardarPuntuacion($_SESSION['usuario'],$_SESSION['puntuacion']);
        guardar_quesitos_sesion($_SESSION['usuario'], $quesitos);
        guardar_numPreg($_SESSION['usuario'], 1);
    elseif(isset($_COOKIE['anonimo'])):
        actualizar_Cookie2($puntuacion,0,$quesitos);
    endif;
    
    //Comprobamos si ya se han reunido todos los quesitos
    if(comprobarQuesitos($quesitos)):
        header("location:../finJuego.php");
        die;
    endif;
    
    header("location:../juego.php");
    
}




