<?php

//Comprobamos si existe una cookie con el usuario anonimo
if(!isset($_COOKIE['user_anonimo'])): 
    
    //Si no existe creamos el usuario anonimo.
    $datosUsuarioAnonimo = [
        "puntuacion" => "0",
        "num_preguntas" => "0",
        "quesitos" => serialize(["!Ciencia","!Cultura General","!Deportes","!Entretenimiento","!Geografía","!Historia"])
    ];

    //Creamos una cookie que dura 7 días.
    setcookie("user_anonimo", serialize($datosUsuarioAnonimo), time()+3600*7*24,"/");
    header("location:../juego.php");
elseif(isset($_COOKIE['user_anonimo']) && isset($_POST['eleccion'])) :
    if($_POST['eleccion'] == "continuar"):
        header("location:../juego.php");
        die;
    elseif($_POST['eleccion'] == "nueva"):
        setcookie("user_anonimo","", time()-3600*7*24,"/");
        header("location:../index.php");
        die;
    endif;
elseif(isset($_COOKIE['user_anonimo'])):
    header("location:../partidaIniciada.php");
endif;




