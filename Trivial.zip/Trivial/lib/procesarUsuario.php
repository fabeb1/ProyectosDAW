<?php
session_start();
    include '../funciones/funcionesSession.php';
    include '../funciones/funcionesFicheroUsuario.php';
    //Comprobamos que tenemos los datos en el post
    //print_r($_POST);
    
    if(isset($_POST) && !empty($_POST)){
        /**
         * Comprobamos si se ha pulsadoe el boton de salir de la partida.
         */
        if(isset($_POST['salirPartida']) && !empty($_POST['salirPartida'])){
            if(isset($_SESSION['usuario'])){
                session_destroy();
                header("location:../index.php");
                die;
            }elseif($_COOKIE['user_anonimo']){
                header("location:../index.php");
                die;
            }
            
        }
        
        //Comprobamos si se ha rellenado el formulario de registro de usuario
        if(isset($_POST['registrar']) && !empty($_POST['registrar'])){
            //Comprobamos los datos insertados en el formulario
            if(!isset($_POST['user']) || empty($_POST['user']) || 
                    !isset($_POST['pass']) || empty($_POST['pass']) ||
                    !isset($_POST['passConf']) || empty($_POST['passConf'])){
                
                $mensaje = "Error! no se han rellenado todos los datos";
                header("location:../index.php?m=".urlencode($mensaje));
                die;
                //Enviamos el mensaje de error al index
                
            }else{
                
                //Si las contraseñas no coinciden guardamos el mensaje
                if($_POST['pass']!== $_POST['passConf']){
                    $mensaje = "Error! Las contraseñas no coinciden";
                    header("location:../index.php?m=".urlencode($mensaje));
                    die;
                //Si el usuario existe guardamos el mensaje    
                }else if(userExist($_POST['user'])){
                    $mensaje = "El usuario ya existe.";
                    header("location:../index.php?m=".urlencode($mensaje));
                    die;
                }else{
                    //Guardamos los datos del formulario para procesarlos
                    $nameUser = trim($_POST['user']);
                    $passUser = trim($_POST['pass']);
                    //Si no existe registramos el usuario
                    registrarUsuario($nameUser, $passUser);
                    $mensaje = "Usuario Registrado, Iniciar Sesión";
                    header("location:../index.php?m=".urlencode($mensaje));
                    die;
                }
            }
            
        //Si es un inicio de sesion procesamos la sesíon.
        }else if(isset($_POST['login']) && !empty($_POST['login'])){
            //Comprobamos que los campos esten asignados y no estén vacios
            if(!isset($_POST['user']) || empty($_POST['user'])
                    || !isset($_POST['pass']) || empty($_POST['pass'])){
                $mensaje = "Error! No se ha rellenado correctamente el formulario.";
                header("location:../index.php?m=".urlencode($mensaje));
                die();
            }

            //Guardamos los datos que ha insertado el usuario.
            $user = $_POST['user'];
            $pass = $_POST['pass'];
            
            
            //Si no existe el usuario o la contraseña no coincide entonces pasamos el error.
            if(!userExist($user)){
                $mensaje = "Error! Usuario o contraseña incorrectos.";
                header("location:../index.php?m=".urlencode($mensaje));
                die;
            }
            
            //Obtenemos los datos del usuario
            $datosUser = buscarUsuario($user);
            //si los datos están vacios muestra un error.
            if(empty($datosUser)){
                $mensaje = "Error! No se han podido obtener los datos del usuario.<br/> Crea un nuevo usuario.";
                header("location:../index.php?m=".urlencode($mensaje));
                die;
            }
            
            //Comprobamos que la contraseña coincida 
            if(!password_verify($pass, $datosUser[1])){
                $mensaje = "Error! Usuario o contraseña incorrectos.";
                header("location:../index.php?m=".urlencode($mensaje));
                die;
            }
            
            //Iniciamos sesion...
            iniciar_sesion($datosUser);
            header("location:../juego.php");
            
            
            
            
        }
    } 
