<?php
session_start();
include '../funciones/funcionesFicheroUsuario.php';
include '../funciones/funcionesSession.php';
include '../funciones/funcionesCookies.php';



print_r($_POST);

if(isset($_POST) && !empty($_POST)){
    if(!isset($_POST['opcion'])||empty($_POST['opcion']) ||
       !isset($_POST['contador']) ||
       !isset($_POST['solucion'])||empty($_POST['solucion'])){
        echo "<script>alert('Error! algo mal ha sucedido... volovemos atras.')</script>";
        header("location:../juego.php");
        die;
    }else{
        $contador = $_POST['contador'];
        $solucion = $_POST['solucion'];
        if(password_verify($_POST['opcion'], $solucion)){
            $puntuacion =5;
        }else{
            $puntuacion =-2;
        }
    }
    if(isset($_SESSION['usuario'])):
        //Actualizamos la puntuación según el resultado obtenido.
        $_SESSION['puntuacion'] = $_SESSION['puntuacion']+ $puntuacion;
        $_SESSION['num_preguntas'] = $contador+1;
        //Guardamos la puntuación en el fichero.
        guardarPuntuacion($_SESSION['usuario'],$_SESSION['puntuacion']);
        guardar_numPreg($_SESSION['usuario'], $contador+1);
        
    elseif(isset($_COOKIE['user_anonimo'])):
        actualizar_Cookie($puntuacion,$contador+1);
        //actualizar_num_preguntas_Cookie($contador+1);
    endif;
    
    $pregunta_queso = (rand(1,3) == 1) ? true :false;
    $contador = $_POST['contador']+1;
    if($pregunta_queso && ($contador+1) > 3){
        header("location:../categoria_queso.php");
    }else{
        header("location:../juego.php?contador=".$contador);
    }
    
    
    
}

