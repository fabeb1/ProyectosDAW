<?php
session_start();
include '../funciones/funcionesCookies.php';
include '../funciones/funcionesFicheroUsuario.php';
include '../funciones/funcionesSession.php';

//Comprobamos los valores pasados por el formulario
if(isset($_POST) && !empty($_POST)){
    if(isset($_POST['opcion']) && !empty($_POST['opcion']) &&
            isset($_POST['puntuacion']) && !empty($_POST['puntuacion'])):
        
        $puntuacion = $_POST['puntuacion'];
        if (isset ($_SESSION['usuario'])) :
            //Si se ha inicido sesion entonces guardamos la puntuacion total
            guardarResultadosFinales($_SESSION['usuario'], $puntuacion);
            //Reinicimos los datos de los ficheros
            reiniciarDatos_ficheros($_SESSION['usuario']);
            //Buscamos los datos del usuario y reiniciamos los valores de la sesion;
            $datosUser = buscarUsuario($_SESSION['usuario']);
            //si los datos están vacios muestra un error.
            if(empty($datosUser)):
                $mensaje = "Error! No se han podido obtener los datos del usuario.<br/> Crea un nuevo usuario.";
                header("location:../index.php?m=".urlencode($mensaje));
                die;
            endif;
            iniciar_sesion($datosUser);
            
        elseif(isset($_COOKIE['user_anonimo'])):
            //Reiniciamos los valores de la cookie
            reiniciarDatos();
        endif;
        
        if($_POST['opcion']==="si"):
            header("location:../juego.php");
            die;
        elseif ($_POST['opcion']==="no"):
            if(isset($_SESSION['usuario'])):
                session_destroy();
            elseif(isset($_COOKIE['user_anonimo'])):
                borrarCookie();
            endif;
            
            
            header("location:../index.php");
        endif;
    endif;
}

