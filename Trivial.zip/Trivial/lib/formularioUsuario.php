<html>
    <head>
        
        
    </head>
    <body>
       
        
        <main>
            <h2 class="registro">Registrar Usuario</h2>
            <h2 class="login">Iniciar Sesión</h2>
            <form action="../lib/procesarUsuario.php" method="post">
                <div>
                    <label for="user">Nombre de usuario:</label><br/>
                    <input type="text" name="user" id="user" placeholder="user" required/>
                </div>
                <div>
                    <label for="pass">Inserte contraseña:</label><br/>
                    <input type="password" name="pass" id="pass" placeholder="contraseña" required />
                </div>
                <div class="registro">
                    <label for="pass">Confirme contraseña:</label><br/>
                    <input  type="password" name="passConf" id="passConf" placeholder="contraseña" value="pass" required />
                </div>
                <div> 
                    <input class="registro" type="submit" name="registrar" value="Registrarse">
                    <input class="login" type="submit" name="login" value="login">
                    <input class="login" type="button" value="Registrar Usuario" onclick="mostrarReg()">
                    <a class="registro" href="" onclick="">Iniciar Sesión</a>
                    <a href="lib/jugarAnonimo.php">Jugar de forma anónima</a>                   
                </div>
            </form>
            <div>
                
            </div>
        </main>
            
    </body>
</html>