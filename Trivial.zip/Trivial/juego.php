<?php 
session_start();
include 'funciones/funcionesFicheroPreguntas.php';
include './funciones/funcionesJuego.php';
include './funciones/funcionesCookies.php';
$arrayQuesitos = ["Ciencia","Cultura General","Deportes","Entretenimiento","Geografía","Historia"];
$contador=1;

//Si se ha iniciado sesion se carga los datos de la sesion.
if(isset($_SESSION['usuario'])){
    $usuario = $_SESSION['usuario'];
    $puntuacion = $_SESSION['puntuacion'];
    $quesitos = $_SESSION['quesitos'];
    $num_preguntas = $_SESSION['num_preguntas'];
    $contenido = file_get_contents("usuarios/$usuario/puntuaciones.txt");
    $puntuaciones = unserialize($contenido);
}elseif(isset ($_COOKIE['user_anonimo'])){
    $usuario = "user_anonimo";
    $puntuacion = obtener_puntuacion_cookie();
    $quesitos = obtener_quesitos_cookie();
    $num_preguntas = obtener_num_preguntas_cookie();
}else{
    header("location:index.php");
}


if(comprobarQuesitos($quesitos)):
    header("location:finJuego.php");
    die;
endif;

//Primero se elige de forma aleatoria la pregunta
$categoria = categoriaAleatoria();
//Obtenemos la pregunta de la categoría elegida.
$linea = ObtenerPregunta($categoria);
$solucion = password_hash($linea[6], PASSWORD_DEFAULT);

?>
<html>
    <head>
        <title>Trivial</title>
        <style>
            body{
                margin: 0;
                height: 100%;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: center;
                font-size: 1.3em;
                background-image: url("imagenes/trivial.avif")
            }
            
            header{
                background-color: cadetblue;
                width: 100%;
                text-align: center;
            }
            
            header form{margin: 0;}
            
            header form input{width: 50%}
            
            main{
                width: 100%;
                display: flex;
                flex-direction: row;
            }
            
            .ranking{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
                width: 20%;
                background-color: antiquewhite;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            
            .principal{
                width: 80%;
                display: flex;
                justify-content: center;
            }
            
            .contenedor{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
            }
            
            .pregunta{
                border: solid black 2px;
                border-radius: 10px;
                padding: 5px;
                background-color: white;
                margin-bottom: 5px;
            }
            
            .opciones{
                display: flex;
                background-color: lightblue;
                border: solid black 2px;
                border-radius: 10px;
                flex-flow: row wrap;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 5px;
            }
            
            .opciones h3{width: 100%}
            
            .opciones button{
                padding: 10px;
                color: white;
                text-align: center;
                border: 2px solid black;
                border-radius: 10px;
                background-color: steelblue;
                transition: 0.5s linear;
                width: 40%;
                margin: 3px;
                cursor: grab;
            }
            
            .opciones button:hover{
                transform: scale(1.05);
                background-color: orange;
                box-shadow: 3px 3px 3px black;
            }
            
            footer{
                background-color: cadetblue;
                width: 100%;
            }
        </style>
        <script src="funciones/funcionesJavaScript.js"></script>
    </head>
    <body>
        <header>
            
            <h1>TRIVIA</h1>
            <div>
                <form action="lib/procesarUsuario.php" method="post">
                    <input type="submit" name="salirPartida" value="Salir"/>
                </form>
            </div>
            
        </header>
        <main>
            <div class="ranking">
                <h2>Ranking</h2>
                <table>
                    <tr>
                        <th>puntuacion</th>
                        <th>fecha</th>
                    </tr>
                    <?php 
                        if(isset($_SESSION['usuario']) && !empty($puntuaciones)):
                            $contadorRank = 0;
                            for($i =0;$i< count($puntuaciones);$i++): 
                                $value = $puntuaciones[$i];?>
                                
                                <tr>
                                    <td><?php echo $value['puntuacion']; ?></td>
                                    <td><?php echo $value['fecha']; ?></td>
                                </tr>
                                
                            <?php 
                                if($i>=10):
                                    $i = count($puntuaciones);
                                endif;
                            endfor;
                        endif;  ?>
                        
                </table>
            </div>
            <div class="principal">
                <div class="contenedor">
                    <h2>Categoría: <?php echo $categoria; ?></h2>
                    <div class="pregunta">
                        <p>Pregunta:</p>
                        <p><?php echo $linea[1]; ?></p>
                    </div>

                    <form class="opciones" action="lib/procesarRespuesta.php" method="post">
                        <h3>Opciones:</h3>
                        <input type="hidden" name="contador" value='<?php echo $num_preguntas; ?>'>
                        <input type="hidden" name="solucion" value='<?php echo $solucion; ?>'>
                        <?php for ($i = 2;$i<count($linea)-1;$i++): ?>
                        <button name="opcion" value="<?php echo $linea[$i]; ?>"><?php echo $linea[$i]; ?></button>
                        <?php endfor; ?>
                    </form>
                </div>
            </div>
        </main>
        <footer>
            <h3>PUNTUACIÓN: <?php echo $puntuacion; ?></h3>
            <h3>QUESITOS OBTENIDOS: <?php echo mostrarQuesitos($quesitos); ?> </h3>
        </footer>
    </body>
</html>
