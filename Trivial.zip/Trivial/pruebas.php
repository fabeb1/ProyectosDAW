<?php
include './funciones/funcionesFicheroUsuario.php';
guardarResultadosFinales("Fabricio", 10);