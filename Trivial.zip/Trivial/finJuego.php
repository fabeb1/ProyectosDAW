<?php 
session_start();
include 'funciones/funcionesFicheroPreguntas.php';
include './funciones/funcionesJuego.php';
include './funciones/funcionesCookies.php';

//Si se ha iniciado sesion se carga los datos de la sesion.
if(isset($_SESSION['usuario'])){
    $usuario = $_SESSION['usuario'];
    $puntuacion = $_SESSION['puntuacion'];
    $quesitos = $_SESSION['quesitos'];
    $num_preguntas = $_SESSION['num_preguntas'];
}elseif(isset ($_COOKIE['user_anonimo'])){
    $usuario = "user_anonimo";
    $puntuacion = obtener_puntuacion_cookie();
    $quesitos = obtener_quesitos_cookie();
    $num_preguntas = obtener_num_preguntas_cookie();
}
?>
<html>
    <head>
        <title>Trivial</title>
        <style>
            body{
                margin: 0;
                height: 100%;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: center;
                font-size: 1.3em;
                background-image: url("imagenes/trivial.avif")
            }
            
            header{
                background-color: cadetblue;
                width: 100%;
            }
            
            main{
                width: 100%;
                display: flex;
                flex-direction: row;
            }
            
            .ranking{
                width: 20%;
            }
            
            .principal{
                width: 80%;
                display: flex;
                justify-content: center;
            }
            
            .contenedor{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
            }
            
            .pregunta{
                border: solid black 2px;
                border-radius: 10px;
                padding: 5px;
                background-color: white;
                margin-bottom: 5px;
            }
            
            .opciones{
                display: flex;
                background-color: lightblue;
                border: solid black 2px;
                border-radius: 10px;
                flex-flow: row wrap;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 5px;
            }
            
            .opciones h3{width: 100%}
            
            .opciones button{
                padding: 10px;
                color: white;
                text-align: center;
                border: 2px solid black;
                border-radius: 10px;
                background-color: steelblue;
                transition: 0.5s linear;
                width: 40%;
                margin: 3px;
                cursor: grab;
            }
            
            .opciones button:hover{
                transform: scale(1.05);
                background-color: orange;
                box-shadow: 3px 3px 3px black;
            }
            
            footer{
                background-color: cadetblue;
                width: 100%;
            }
        </style>
        <script src="funciones/funcionesJavaScript.js"></script>
    </head>
    <body>
        <header>
            <?php 
            echo $num_preguntas;
            print_r($_COOKIE); ?>
            <h1>TRIVIA</h1>
            
        </header>
        <main>
            <div class="ranking">
                <h2>Ranking</h2>
                
            </div>
            <div class="principal">
                <div class="contenedor">
                    <h2>FINAL DE PARTIDA</h2>
                    <div class="pregunta">
                        <p><strong>Has conseguido los quesitos de todas las categorías</strong></p>
                        <p><strong>La puntuación total obtenida ha sido: </strong><?php echo $puntuacion; ?></p>
                    </div>

                    <form class="opciones" action="lib/procesarFinJuego.php" method="post">
                        <h3>Iniciar una nueva Partida:</h3>
                        <input type="hidden" name="puntuacion" value="<?php echo $puntuacion; ?>">
                        <button name="opcion" value="si">SI</button>
                        <button name="opcion" value="no">NO</button>
                    </form>
                </div>
            </div>
        </main>
        <footer>
            <h3>PUNTUACIÓN: <?php echo $puntuacion; ?></h3>
            <h3>QUESITOS OBTENIDOS: <?php echo mostrarQuesitos($quesitos); ?> </h3>
        </footer>
    </body>
</html>
