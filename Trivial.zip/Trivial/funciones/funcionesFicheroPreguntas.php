<?php
/**
 * Función para obtener la categoría de la pregunta.
 * 
 * @return string Devuelve la categoría de la pregunta.
 */
function categoriaAleatoria(){
    $numAleat = rand(1,6);
    $categoria="";
    switch ($numAleat) {
        case 1 : 
            $categoria = "Cultura General";
            break;
        case 2 : 
            $categoria = "Entretenimiento";
            break;
        case 3 : 
            $categoria = "Deportes";
            break;
        case 4 : 
            $categoria = "Ciencia";
            break;
        case 5 : 
            $categoria = "Historia";
            break;
        default:
            $categoria = "Geografía";
            break;
    }
    
    return $categoria;
}

/**
 * Función para obtener de forma aleatoria el número de la pregunta.
 * 
 * @return type Devuelve el numero de la pregunta.
 */
function preguntaAleatoria (){
    $pregunta = rand(2,51);
    return $pregunta;
}

/**
 * Función para obtener la pregunta de la categoría seleccionada
 * 
 * @param type $categoria categoría seleccionada
 * @return type Devuelve la pregunta;
 */
function ObtenerPregunta ($categoria) {
    $path = "";
    switch ($categoria) {
        case "Cultura General":
            $path = "archivos/cultura_general.csv";
            break;
        case "Entretenimiento":
            $path = "archivos/entretenimiento.csv";
            break;
        case "Deportes":
            $path = "archivos/deportes.csv";
            break;
        case "Ciencia":
            $path = "archivos/ciencia.csv";
            break;
        case "Historia":
            $path = "archivos/historia.csv";
            break;
        default:
            $path = "archivos/geografia.csv";
            break;
    }
    $stream = fopen($path, "r");
    
    $contador = 0;
    $num_pregunta = preguntaAleatoria();
    while ($contador < $num_pregunta){
        $linea = fgetcsv($stream, null,";");
        $contador++;
    }
    return $linea;
}

