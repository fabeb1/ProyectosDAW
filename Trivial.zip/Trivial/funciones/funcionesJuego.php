<?php

function mostrarQuesitos($quesitos) {
    $arrayQuesitos = ["Ciencia","Cultura General","Deportes","Entretenimiento","Geografía","Historia"];
    $mostrarQuesitos ="";
    for ($i = 0; $i < count($quesitos); $i++) :
        if($quesitos[$i] == $arrayQuesitos[$i]){
            $mostrarQuesitos = $mostrarQuesitos."--".$arrayQuesitos[$i];
        }
    endfor;
    return $mostrarQuesitos;
}

function comprobarQuesitos($quesitos){
    $arrayQuesitos = ["Ciencia","Cultura General","Deportes","Entretenimiento","Geografía","Historia"];
    $contador=0;
    for($i=0;$i<count($arrayQuesitos);$i++):
        if($arrayQuesitos[$i]===$quesitos[$i]):
            $contador++;
        endif;
    endfor;
    if($contador==6):
        return true;
    endif;
    return false;
}

