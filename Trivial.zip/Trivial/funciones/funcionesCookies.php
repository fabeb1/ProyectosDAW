<?php
/**
 * Funcion para obtener los datos de la cookie.
 * 
 * @return type Devuelve los datos de la cookie.
 */
function obtenerDatos() {
    if(isset($_COOKIE['user_anonimo'])){
        $usurio = unserialize($_COOKIE['user_anonimo']);
    }
    return $usurio;
}

function reiniciarDatos() {
    $datosUsuarioAnonimo = [
        "puntuacion" => "0",
        "num_preguntas" => "0",
        "quesitos" => serialize(["!Ciencia","!Cultura General","!Deportes","!Entretenimiento","!Geografía","!Historia"])
    ];

    //Creamos una cookie que dura 7 días.
    setcookie("user_anonimo", serialize($datosUsuarioAnonimo), time()+3600*7*24,"/");
    header("location:../juego.php");
}



/**
 * Funcion para actualizar la cookie
 * @param type $puntuacion
 * @param type $num_preguntas
 */
function actualizar_Cookie($puntuacion,$num_preguntas) {
    $usuario = obtenerDatos();
    $usuario['puntuacion']=$usuario['puntuacion']+$puntuacion;
    $usuario['num_preguntas']=$num_preguntas;
    setcookie("user_anonimo", serialize($usuario), time()+3600*7*24,"/");
}
/**
 * Funcion para actualizar la cookie
 * @param type $puntuacion
 * @param type $num_preguntas
 * @param type $quesitos
 */
function actualizar_Cookie2($puntuacion,$num_preguntas,$quesitos) {
    $usuario = obtenerDatos();
    $usuario['puntuacion']=$usuario['puntuacion']+$puntuacion;
    $usuario['num_preguntas']=$num_preguntas;
    $usuario['quesitos']= serialize($quesitos);
    setcookie("user_anonimo", serialize($usuario), time()+3600*7*24,"/");
}
/**
 * Funcion para actualizar la puntuacion
 * @param type $puntuacion
 */
function actualizar_puntuacion_Cookie($puntuacion) {
    $usuario = obtenerDatos();
    $usuario['puntuacion']=$usuario['puntuacion']+$puntuacion;
    
    setcookie("user_anonimo", serialize($usuario), time()+3600*7*24,"/");
}

/**
 * Funcion para actualizar el número de preguntas realizadas.
 * 
 * @param type $num_preguntas
 */
function actualizar_num_preguntas_Cookie($num_preguntas) {
    $usuario = obtenerDatos();
    $usuario['num_preguntas']=$usuario['num_preguntas']+$num_preguntas;
    setcookie("user_anonimo", serialize($usuario), time()+3600*7*24,"/");
}

/**
 * Funcion para actualizar los quesitos que ha ganado
 * 
 * @param type $quesitos
 */
function actualizar_quesitos_cookie($quesitos) {
    $usuario = obtenerDatos();
    $usuario['quesitos']= serialize($quesitos);
    setcookie("user_anonimo", serialize($usuario), time()+3600*7*24,"/");
}

/**
 * Funcion para obtener la puntuacion
 * @return type
 */
function obtener_puntuacion_cookie() {
    $usuario = obtenerDatos();
    return $usuario['puntuacion'];
}

/**
 * Función para obtener los quesitos que ha ganado
 * @return type
 */
function obtener_quesitos_cookie() {
    $usuario = obtenerDatos();
    return unserialize($usuario['quesitos']);
}
/**
 * Funcion para obtener el numero de preguntas realizadas
 * @return type
 */
function obtener_num_preguntas_cookie() {
    $usuario = obtenerDatos();
    return $usuario['num_preguntas'];
}

/**
 * Funcion para borrar la cookie
 */
function borrarCookie() {
    setcookie("user_anonimo", "", time()-3600,"/");
}