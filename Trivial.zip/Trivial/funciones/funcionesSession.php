<?php

/**
 * Función para iniciar la sesión con los datos guardados del usuario
 * 
 * @param type $usuario Usuario que inicia sesion.
 */
function iniciar_sesion($usuario){
    $_SESSION['usuario'] = $usuario[0];
    $_SESSION['puntuacion'] = $usuario[2];
    $_SESSION['quesitos'] = unserialize($usuario[3]);
    $_SESSION['num_preguntas'] =$usuario[4];
}

/**
 * Funcion para actualizar la puntuación
 * 
 * @param type $puntuacion la puntuación de la partida
 */
function actualizar_puntuacion ($puntuacion){
    $_SESSION['puntuacion'] = $puntuacion;
}

/**
 * Función para actualizar los quesitos que ha conseguido.
 * 
 * @param type $quesito quesito ganado.
 */
function actualizar_quesitos_sesion($quesito){
    $_SESSION['quesitos'] = $_SESSION['quesitos']." ".$quesito;
}

function actualizar_numPreg_sesion($num) {
    $_SESSION['puntuacion'] = $num;
}

/**
 * Función para guardar la session en un fichero
 */
function guarda_session(){
    $user = $_SESSION['usuario'];
    $puntuacion = $_SESSION['puntuacion'];
    $quesitos = $_SESSION['quesitos'];
    
    guardarDatosUsuario($user, $puntuacion, $quesitos);
}


