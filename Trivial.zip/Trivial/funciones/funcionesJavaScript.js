function mostrarReg (){
    document.getElementById("passConf").value="";
    
    let loginElems = document.getElementsByClassName("login");
    let registrElems =document.getElementsByClassName("registro");
    
    
    for (let i = 0;i<loginElems.length;i++){
        loginElems[i].style.display="none";
    }
    for(let i = 0;i<registrElems.length;i++){
        registrElems[i].style.display="inline";
    }
}




