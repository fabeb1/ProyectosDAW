<?php

/*
 *Función para comprobar si exista la Carpeta de Usuarios, si no 
 * exisste la crea 
 *  
 */
function comprobarCarpetaUsuarios() {
    if(!file_exists("../usuarios")){
        //crea una carpeta archivos si esta no existe
        mkdir("../usuarios");
    }
    
}

/**
 * Función que comprueba si existe el fichero usuarios
 * 
 * @return bool
 */
function comprobarArchivoUsuarios(){
    comprobarCarpetaUsuarios();
    if(!file_exists("../usuarios/usuarios.txt")){
        return false;
    }
    return true;
}

/**
 * Funcion para comprobar si existe el usuario.
 * 
 * @param type $nameUser nombre del usuario
 * @return bool true si existe en el fichero de usuarios/ false en caso contrario.
 */
function userExist($nameUser){
    //Comprobamos si existe el archiivo usuarios.
    if(!comprobarArchivoUsuarios()){
        return false;
    }
    //Abrimos el archivo usuarios
    $stream = fopen("../usuarios/usuarios.txt", "r");
    
    //Obtenemos las lineas del fichero hasta que haya una coincidencia.
    while ($linea = fgets($stream)){
        if($nameUser == explode(" ", $linea)[0]){
            fclose($stream);
            return true;
        }
    }
    //Si no ha habido una coincidencia entonces devolvemos false.
    fclose($stream);
    return false;
}

/**
 * Función para buscar un usuario
 * 
 * @param type $nameUser nombre del usuario
 * @return array devuelve un array con los datos.
 */
function buscarUsuario($nameUser) {
    $user_directorio = "../usuarios/$nameUser";
    if(file_exists($user_directorio)){
        if(file_exists("$user_directorio/.password")){
            $pass = file_get_contents("$user_directorio/.password");
            echo $pass;
        }else {
            return;
        }
        if(file_exists("$user_directorio/puntuacionActual.txt")){
            $puntuacionActual = file_get_contents("$user_directorio/puntuacionActual.txt");
            echo $puntuacionActual;
        }
        else{
            return;
        }
        if(file_exists("$user_directorio/quesitosObtenidos.txt")){
            $quesitos = file_get_contents("$user_directorio/quesitosObtenidos.txt");
            echo $quesitos;
        }else {
            return;
        }
        if(file_exists("$user_directorio/num_preguntas.txt")){
            $num_preguntas = file_get_contents("$user_directorio/num_preguntas.txt");
            echo $num_preguntas;
        }else {
            return;
        }
        
        return [$nameUser,$pass,$puntuacionActual,$quesitos,$num_preguntas];
    }
    
    
    return;
}

/**
 * Función para crear los directorios y ficheros del usuario
 * que se está registrando.
 * 
 * @param type $nameUser nombre del usuario.
 * @param type $passUser contraseña del usuario.
 */
function registrarUsuario($nameUser,$passUser){
   //Abrimos el archivo usuarios
    $stream = fopen("../usuarios/usuarios.txt", "a");
    //Escribimos en el archivo
    fputs($stream, $nameUser." ".$passUser." "."0"." "."0-0-0-0-0-0"." ".PHP_EOL);
    //cerramos el fichero
    fclose($stream);
    $user_directorio = "../usuarios/$nameUser";
    //Creamos el directorio y archivos del usuario con su contenido inicial.
    mkdir("$user_directorio");
    //En el archivo de la contraseña la guardamos hasheada
    file_put_contents("$user_directorio/.password", password_hash($passUser, PASSWORD_DEFAULT));
    file_put_contents("$user_directorio/puntuaciones.txt", "");
    file_put_contents("$user_directorio/puntuacionActual.txt","0");
    $quesitos = ["!Ciencia","!Cultura General","!Deportes","!Entretenimiento","!Geografía","!Historia"];
    file_put_contents("$user_directorio/quesitosObtenidos.txt", serialize($quesitos));
    file_put_contents("$user_directorio/num_preguntas.txt", "0");
    
}

function reiniciarDatos_ficheros($nameUser) {
    $user_directorio = "../usuarios/$nameUser";
    file_put_contents("$user_directorio/puntuacionActual.txt","0");
    $quesitos = ["!Ciencia","!Cultura General","!Deportes","!Entretenimiento","!Geografía","!Historia"];
    file_put_contents("$user_directorio/quesitosObtenidos.txt", serialize($quesitos));
    file_put_contents("$user_directorio/num_preguntas.txt", "0");
}

function guardarPuntuacion($user,$puntuacion) {
    $user_directorio = "../usuarios/$user";
    file_put_contents("$user_directorio/puntuacionActual.txt",$puntuacion);
}

function guardar_numPreg($user,$contador){
    $user_directorio = "../usuarios/$user";
    file_put_contents("$user_directorio/num_preguntas.txt",$contador);
}

function guardar_quesitos_sesion($user,$quesitos) {
    $user_directorio = "../usuarios/$user";
    file_put_contents("$user_directorio/quesitosObtenidos.txt", serialize($quesitos));
}

function guardar_num_preguntas_sesion($user,$num) {
    $user_directorio = "../usuarios/$user";
    file_put_contents("$user_directorio/num_preguntas.txt", $num);
}

function ordenarPuntuacionesTotales($puntuaciones){
    usort($puntuaciones, function ($a,$b) {
        return $b['puntuacion']-$a['puntuacion'];
    });
    return $puntuaciones;
}

function guardarResultadosFinales($user,$puntuacion) {
    $fecha = date('Y-m-d H:i:s');
    $user_directorio = "../usuarios/$user";
    echo $user_directorio;
    $contenido = file_get_contents("$user_directorio/puntuaciones.txt");
    if(empty($contenido)){
        $puntuaciones [] = ['puntuacion' => $puntuacion,'fecha'=> $fecha];
        file_put_contents("$user_directorio/puntuaciones.txt", serialize($puntuaciones));
    }else{
        $puntuaciones = unserialize($contenido);
        $puntuaciones [] = ['puntuacion' => $puntuacion,'fecha'=> $fecha];
        $puntuaciones = ordenarPuntuacionesTotales($puntuaciones);
        file_put_contents("$user_directorio/puntuaciones.txt", serialize($puntuaciones));
    }
}

function obtenerPuntuacionesTotales($user) {
    return serialize(file_get_contents("usuarios/$user/puntuaciones.txt"));
}