<?php 
session_start();
include 'funciones/funcionesFicheroPreguntas.php';
include 'funciones/funcionesJuego.php';
include './funciones/funcionesCookies.php';

$categoria = "";

//Comprobamos si esta iniciada la session 
if(isset($_SESSION['usuario'])){
    $usuario = $_SESSION['usuario'];
    $puntuacion = $_SESSION['puntuacion']; 
    $quesitos = $_SESSION['quesitos'];
//Si no estaár iniciada la partida de forma anónima
}elseif(isset ($_COOKIE['user_anonimo'])){
    $usuario = "aninimo";
    $puntuacion = obtener_puntuacion_cookie();
    $quesitos = obtener_quesitos_cookie();
    $num_preguntas = obtener_quesitos_cookie();
}else{
    header("location:index.php");
}

if(isset($_POST) && !empty($_POST)){
    if(isset($_POST['categoria']) && !empty($_POST['categoria'])){
        $categoria = $_POST['categoria'];
    }
}

if(comprobarQuesitos($quesitos)):
    header("location:finJuego.php");
    die;
endif;

//Obtenemos la pregunta de la categoría elegida.
$linea = ObtenerPregunta($categoria);

$solucion = password_hash($linea[6], PASSWORD_DEFAULT);
?>
<html>
    <head>
        <title>Trivial</title>
        <style>
            body{
                margin: 0;
                height: 100%;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: center;
                font-size: 1.3em;
                background-image: url("imagenes/trivial.avif")
            }
            
            header{
                background-color: cadetblue;
                width: 100%;
                text-align: center;
            }
            
            header form{margin: 0;}
            
            header form input{width: 50%}
            
            main{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
            }
            
            .pregunta{
                border: solid black 2px;
                border-radius: 10px;
                padding: 5px;
                background-color: white;
                margin-bottom: 5px;
            }
            
            .opciones{
                display: flex;
                background-color: lightblue;
                border: solid black 2px;
                border-radius: 10px;
                flex-flow: row wrap;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 5px;
            }
            
            .opciones h3{width: 100%}
            
            .opciones button{
                padding: 10px;
                color: white;
                text-align: center;
                border: 2px solid black;
                border-radius: 10px;
                background-color: steelblue;
                transition: 0.5s linear;
                width: 40%;
                margin: 3px;
                cursor: grab;
            }
            
            .opciones button:hover{
                transform: scale(1.05);
                background-color: orange;
                box-shadow: 3px 3px 3px black;
            }
            
            footer{
                background-color: cadetblue;
                width: 100%;
            }
        </style>
        <script src="funciones/funcionesJavaScript.js"></script>
    </head>
    <body>
        <header>
            <h1>TRIVIA</h1>
            <div>
                <form action="lib/procesarUsuario.php" method="post">
                    <input type="submit" name="salirPartida" value="Salir"/>
                </form>
            </div>
        </header>
        <main>
            <h2>Pregunta por el quesito de la categoría: <?php echo $categoria; ?></h2>
            <div class="pregunta">
                <p>Pregunta:</p>
                <p><?php echo $linea[1]; ?></p>
            </div>
            
            <form class="opciones" action="lib/procesarRespuestaQueso.php" method="post">
                <h3>Opciones:</h3>
                <input type="hidden" name="categoria" value='<?php echo $categoria; ?>'>
                <input type="hidden" name="solucion" value='<?php echo $solucion; ?>'>
                <?php for ($i = 2;$i<count($linea)-1;$i++): ?>
                <button name="opcion" value="<?php echo $linea[$i]; ?>"><?php echo $linea[$i]; ?></button>
                <?php endfor; ?>
            </form>
        </main>
        <footer>
            <h3>PUNTUACIÓN: <?php echo $puntuacion; ?></h3>
            <h3>QUESITOS OBTENIDOS: <?php echo mostrarQuesitos($quesitos); ?> </h3>
        </footer>
    </body>
</html>
