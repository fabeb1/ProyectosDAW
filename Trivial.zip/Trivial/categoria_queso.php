<?php 
session_start();
include 'funciones/funcionesFicheroPreguntas.php';
include './funciones/funcionesJuego.php';
include './funciones/funcionesCookies.php';
//print_r($_SESSION)
$arrayQuesitos = ["Ciencia","Cultura General","Deportes","Entretenimiento","Geografía","Historia"];

if(isset($_SESSION['usuario'])){
    $usuario = $_SESSION['usuario'];
    $puntuacion = $_SESSION['puntuacion']; 
    $quesitos = $_SESSION['quesitos'];
}elseif(isset ($_COOKIE['user_anonimo'])){
    $puntuacion = obtener_puntuacion_cookie();
    $quesitos = obtener_quesitos_cookie();
}else{
    header("location:index.php");
}

if(comprobarQuesitos($quesitos)):
    header("location:finJuego.php");
    die;
endif;

?>
<html>
    <head>
        <title>Trivial</title>
        <style>
            body{
                margin: 0;
                height: 100%;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: center;
                font-size: 1.3em;
                background-image: url("imagenes/trivial.avif")
            }
            
            header{
                background-color: cadetblue;
                width: 100%;
                text-align: center;
            }
            
            header form{margin: 0;}
            
            header form input{width: 50%}
            
            main{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
            }
            
            .pregunta{
                border: solid black 2px;
                border-radius: 10px;
                padding: 5px;
                background-color: white;
                margin-bottom: 5px;
            }
            
            .opciones{
                display: flex;
                background-color: lightblue;
                border: solid black 2px;
                border-radius: 10px;
                flex-flow: row wrap;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 5px;
            }
            
            .opciones h3{width: 100%}
            
            .opciones button{
                padding: 10px;
                color: white;
                text-align: center;
                border: 2px solid black;
                border-radius: 10px;
                background-color: steelblue;
                transition: 0.5s linear;
                width: 40%;
                margin: 3px;
                cursor: grab;
            }
            
            .opciones button:hover{
                transform: scale(1.05);
                background-color: orange;
                box-shadow: 3px 3px 3px black;
            }
            
            footer{
                background-color: cadetblue;
                width: 100%;
            }
        </style>
        <script src="funciones/funcionesJavaScript.js"></script>
    </head>
    <body>
        <header>
            <h1>TRIVIA</h1>
            <div>
                <form action="lib/procesarUsuario.php" method="post">
                    <input type="submit" name="salirPartida" value="Salir"/>
                </form>
            </div>
        </header>
        <main>
            <h2>Pregunta por el quesito</h2>
            <form class="opciones" action="pregunta_queso.php" method="post">
                <h3>Selecciona la categoría:</h3>
                <?php 
                for ($i = 0;$i< count($arrayQuesitos);$i++): 
                    if($quesitos[$i]!=$arrayQuesitos[$i]):?>
                        <button name="categoria" value="<?php echo $arrayQuesitos[$i]; ?>"><?php echo $arrayQuesitos[$i]; ?></button>
                    <?php endif; ?>
                <?php endfor; ?>
            </form>
        </main>
        <footer>
            <h3>PUNTUACIÓN: <?php echo $puntuacion; ?></h3>
            <h3>QUESITOS OBTENIDOS: <?php echo mostrarQuesitos($quesitos); ?> </h3>
        </footer>
    </body>
</html>
