<html>
    <head>
        <title>Trivial</title>
        <style>
            body{
                margin: 0;
                height: 100%;
                display: flex;
                flex-direction: column;
                gap: 150px;
                align-items: center;
                font-size: 1.3em;
                background-image: url("imagenes/trivial.avif")
            }
            
            header{
                background-color: cadetblue;
                width: 100%;
            }
            
            main{
                border: 3px solid black;
                border-radius: 20px;
                padding: 20px;
                background-color: antiquewhite;
                box-shadow: 3px 3px 3px grey;
            }
            
            .pregunta{
                border: solid black 2px;
                border-radius: 10px;
                padding: 5px;
                background-color: white;
                margin-bottom: 5px;
            }
            
            .opciones{
                display: flex;
                background-color: lightblue;
                border: solid black 2px;
                border-radius: 10px;
                flex-flow: row wrap;
                justify-content: center;
                align-items: center;
                width: 100%;
                padding: 5px;
            }
            
            .opciones h3{width: 100%}
            
            .opciones button{
                padding: 10px;
                color: white;
                text-align: center;
                border: 2px solid black;
                border-radius: 10px;
                background-color: steelblue;
                transition: 0.5s linear;
                width: 40%;
                margin: 3px;
                cursor: grab;
            }
            
            .opciones button:hover{
                transform: scale(1.05);
                background-color: orange;
                box-shadow: 3px 3px 3px black;
            }
            
            footer{
                background-color: cadetblue;
                width: 100%;
            }
        </style>
        <script src="funciones/funcionesJavaScript.js"></script>
    </head>
    <body>
        <header>
            <h1>TRIVIA</h1>
        </header>
        <main>
            <?php print_r($_COOKIE); ?>
            <h2>Hay una partida iniciada de forma anónima desea continuarla o iniciar otra partida:</h2>
            <form class="opciones" action="lib/jugarAnonimo.php" method="post">
                <button name="eleccion" value="continuar">Continuar</button>
                <button name="eleccion" value="nueva">Nueva partida</button>
            </form>
        </main>
    </body>
</html>
