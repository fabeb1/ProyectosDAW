<?php 
session_start();



?>
<html>
    <head>
        <script src="funciones/funcionesJavaScript.js"></script>
        <style>
            body{
                height: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                background-image: url("imagenes/trivial.avif");
            }
            main{
                width: 400px;
                height: 400px;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                background-color: antiquewhite;
                box-shadow: 5px 5px 5px gray;
            }
            main p {
                text-align: center;
                padding: 10px;
                background-color: red;
                box-shadow: 3px 3px 3px gray;
                
            }
            form input, form label{
                margin: 5px;
                width: 100%;
            }
            
            .registro{display: none}
            
            
        </style>
        
    </head>
    <body>
        
        
        <main>
           
            <?php if (isset($_GET["m"])): ?>
                <p><?php echo $_GET["m"]; ?></p>
            <?php endif; ?>
            <h1>TRIVIAL</h1>
            <?php include './lib/formularioUsuario.php'; ?>
        </main>
        
    </body>
</html>

